﻿namespace CA_MVC_Customer.Models
{
    public interface ICustomer
    {
        List<Customer> GetAllCustomers();
    }
}
